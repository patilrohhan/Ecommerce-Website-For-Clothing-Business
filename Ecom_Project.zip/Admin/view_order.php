<?php
// Admin/view_order.php
require_once 'admin_functions.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = intval($_GET['id']);

// Fetch order details and join with customer details
$stmt = $pdo->prepare("SELECT o.*, c.fullname, c.email, o.order_date 
                       FROM orders o 
                       JOIN users_info c ON o.user_id = c.id 
                       WHERE o.id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Order not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Order</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .order-details {
      max-width: 600px;
      margin: 20px auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .order-details p {
      margin: 10px 0;
    }
    .order-details h3 {
      margin-top: 20px;
      color: #357ABD;
    }
  </style>
</head>
<body>
  <header>
    <div class="header-left">Admin Panel</div>
    <div class="header-right">
      <nav>
        <ul>
          <li><a href="index.php">Dashboard</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="orders.php">Orders</a></li>
          <li><a href="customers.php">Customers</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main>
    <div class="order-details">
      <h2>Order Details</h2>
      <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order['id']); ?></p>
      <p><strong>Total:</strong> <?php echo htmlspecialchars($order['total']); ?></p>
      <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
      <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order['order_date']); ?></p>
      <hr>
      <h3>Customer Details</h3>
      <p><strong>Name:</strong> <?php echo htmlspecialchars($order['fullname']); ?></p>
      <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
    </div>
    <div style="text-align: center; margin-top: 20px;">
      <a href="update_order.php?id=<?php echo $order['id']; ?>" class="button">Update Order</a>
    </div>
  </main>
  <footer>
    <p>&copy; <?php echo date("Y"); ?> SKYSHOP. All rights reserved.</p>
  </footer>
</body>
</html>