<?php
// Admin/update_order.php
require_once 'admin_functions.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = intval($_GET['id']);

// Fetch the existing order
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Order not found.";
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'];
    // You can add more fields to update if needed

    $updateStmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    if ($updateStmt->execute([$new_status, $order_id])) {
        header("Location: view_order.php?id=" . $order_id);
        exit();
    } else {
        $error = "Failed to update order status.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Update Order</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .update-form {
      max-width: 500px;
      margin: 20px auto;
      padding: 20px;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .update-form label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    .update-form select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .update-form button {
      padding: 10px 20px;
      background: #4a90e2;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .update-form button:hover {
      background: #357ABD;
    }
    .error {
      color: #e74c3c;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <header>
    <div class="header-left">Admin Panel</div>
    <div class="header-right">
      <nav>
        <ul>
          <li><a href="index.php">Dashboard</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="orders.php">Orders</a></li>
          <li><a href="customers.php">Customers</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main>
    <h2 style="text-align: center;">Update Order</h2>
    <?php if ($error): ?>
      <p class="error" style="text-align: center;"><?php echo $error; ?></p>
    <?php endif; ?>
    <div class="update-form">
      <form method="POST">
        <label for="status">Order Status:</label>
        <select name="status" id="status" required>
          <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
          <option value="Processing" <?php if ($order['status'] == 'Processing') echo 'selected'; ?>>Processing</option>
          <option value="Shipped" <?php if ($order['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
          <option value="Delivered" <?php if ($order['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
          <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
        </select>
        <!-- You can add more input fields here if you wish to update additional details -->
        <button type="submit">Update Order</button>
      </form>
    </div>
  </main>
  <footer>
    <p>&copy; <?php echo date("Y"); ?> SKYSHOP. All rights reserved.</p>
  </footer>
</body>
</html>
