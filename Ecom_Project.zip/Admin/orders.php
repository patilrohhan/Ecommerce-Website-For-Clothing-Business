<?php
// Admin/orders.php
require_once 'admin_functions.php';
requireLogin();

// Retrieve orders with customer information
$stmt = $pdo->query("SELECT o.id, o.total, o.status, c.fullname AS customer_name 
                     FROM orders o
                     JOIN users_info c ON o.user_id = c.id");
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Orders</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Admin Panel</h1>
    <nav>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <h2>Orders</h2>
    <table>
      <thead>
        <tr>
          <th>Order ID</th>
          <th>Customer</th>
          <th>Total</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $order): ?>
          <tr>
            <td><?php echo htmlspecialchars($order['id']); ?></td>
            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
            <td><?php echo htmlspecialchars($order['total']); ?></td>
            <td><?php echo htmlspecialchars($order['status']); ?></td>
            <td>
              <a href="view_order.php?id=<?php echo $order['id']; ?>">View</a>
              <a href="update_order.php?id=<?php echo $order['id']; ?>">Update</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </main>
  <footer>
    <p>&copy; <?php echo date("Y"); ?> SKYSHOP. All rights reserved.</p>
  </footer>
</body>
</html>
