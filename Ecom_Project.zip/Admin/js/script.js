// Admin/js/script.js
document.addEventListener('DOMContentLoaded', function(){
    console.log("Admin panel scripts loaded");
  });
  