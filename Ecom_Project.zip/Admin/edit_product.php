<?php
// Admin/edit_product.php
require_once 'admin_functions.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$id = intval($_GET['id']);
$error = '';

// Fetch existing product
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    // No product found, redirect or show error
    header("Location: products.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $price = floatval($_POST['price']);
    $brand = trim($_POST['brand']);
    $stock = intval($_POST['stock']);

    // Check if new image was uploaded
    $imagePath = $product['image']; // keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $uniqueName = uniqid() . "_" . basename($_FILES['image']['name']);
        $imagePath = $targetDir . $uniqueName;
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
        
        // (Optional) remove old image file to keep folder clean:
        // if (file_exists($product['image'])) {
        //     unlink($product['image']);
        // }
    }
    
    // Update product
    $updateStmt = $pdo->prepare("
        UPDATE products 
        SET title = ?, price = ?, image = ?, brand = ?, stock = ?
        WHERE id = ?
    ");
    $success = $updateStmt->execute([$title, $price, $imagePath, $brand, $stock, $id]);
    
    if ($success) {
        header("Location: products.php");
        exit();
    } else {
        $error = "Failed to update product.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Product</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Admin Panel</h1>
    <nav>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <h2>Edit Product</h2>
    <?php if ($error): ?>
      <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
      <label>Title:</label>
      <input type="text" name="title" value="<?php echo htmlspecialchars($product['title']); ?>" required>
      <br><br>
      
      <label>Price:</label>
      <input type="number" name="price" step="0.01" value="<?php echo htmlspecialchars($product['price']); ?>" required>
      <br><br>

      <label>Stock:</label>
      <input type="number" name="stock" value="<?php echo htmlspecialchars($product['stock']); ?>" required>
      <br><br>

      <label>Brand:</label>
      <input type="text" name="brand" value="<?php echo htmlspecialchars($product['brand']); ?>">
      <br><br>
      
      <label>Current Image:</label>
      <?php if (!empty($product['image'])): ?>
        <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image" style="max-width:80px;">
      <?php else: ?>
        No Image
      <?php endif; ?>
      <br><br>
      
      <label>New Image (optional):</label>
      <input type="file" name="image">
      <br><br>
      
      <button type="submit">Update Product</button>
    </form>
  </main>
  <footer>
    <p>&copy; <?php echo date("Y"); ?> SKYSHOP. All rights reserved.</p>
  </footer>
</body>
</html>
