<?php
// Admin/customers.php
require_once 'admin_functions.php';
requireLogin();

// Retrieve customers from the database
$stmt = $pdo->query("SELECT * FROM users_info");
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Customers</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Admin Panel</h1>
    <nav>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <h2>Customers</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Username</th>
          <th>Email</th>
          <th>Created_At</th>
          <th>Orders</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($customers as $customer): ?>
          <tr>
            <td><?php echo htmlspecialchars($customer['id']); ?></td>
            <td><?php echo htmlspecialchars($customer['fullname']); ?></td>
            <td><?php echo htmlspecialchars($customer['username']); ?></td>
            <td><?php echo htmlspecialchars($customer['email']); ?></td>
            <td><?php echo htmlspecialchars($customer['created_at']); ?></td>
            <td>
              <?php 
              $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
              $stmtCount->execute([$customer['id']]);
              echo $stmtCount->fetchColumn();
              ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </main>
  <footer>
    <p>&copy; <?php echo date("Y"); ?> SKYSHOP. All rights reserved.</p>
  </footer>
</body>
</html>
